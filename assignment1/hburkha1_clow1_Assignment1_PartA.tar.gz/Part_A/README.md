<h2> Assignment 1 </h2>
<h6> CS 550, Spring 2021 </h6>

---
<b> Hannah Burkhard </b>
hburkha3@binghamton.edu

<b> Crystal Low </b>
clow1@binghamton.edu

<b> Assignment description:</b> [Part A] Running foreground and background processes.

---

<h4> General notes </h4>

This zip file includes a Makefile, parser.c, and three test scripts. We believe there are no bugs and the program runs smootly.

We've included the three test scripts: test.sh, test2.sh, test3.sh.
If necessary, use <code> chmod +x [test name] </code> to make them executable.

<h4> How to run </h4>

To Compile the program execute: <code> make all </code>
To Remove all executables execute: <code> make clean </code>

To run the Parser execute: <code> ./parser </code>

Upon execution, the program will prompt the user for input. The following prompt will display: <code> sh550> </code>. Any generic Linux commands, such as <code> ls </code>, can be executed simply by typing the command followed by any arguments into the prompt. In addition, unqiue shell scripts such as the test1, test2, and test3 can be executed by <code> ./test.sh </code>. To run any commands in the background, bypassing the wait, execute with an ampersand & suffix. To list all background jobs currently running in the shell enter the command <code> listjobs </code>. To bring any background process to the foreground enter the command <code> fg </code> followed by the PID. 
