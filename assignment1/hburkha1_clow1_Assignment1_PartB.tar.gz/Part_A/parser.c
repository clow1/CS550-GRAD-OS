#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <assert.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <fcntl.h>

//limits
#define MAX_TOKENS 100
#define MAX_STRING_LEN 100
#define MAX_PROCESSES 100

size_t MAX_LINE_LEN = 10000;


// builtin commands
#define EXIT_STR "exit"
#define EXIT_CMD 0
#define UNKNOWN_CMD 99


FILE *fp; // file struct for stdin
char **tokens;
char ***pipeTokens;
char *line;

int is_bg; //background flag
int *processes; //Array to store PIDs
char **commands; //Array to store background processes command
int processes_count = 0; //Int to store the number of background processes

int redirect_in; //Input redirection falg
int redirect_out; //Output redirection flag
int is_piped; //Pipe flag
char *inputFile;
char *outputFile;

void initialize()
{

	// allocate space for the whole line
	assert( (line = malloc(sizeof(char) * MAX_STRING_LEN)) != NULL);

	// allocate space for individual tokens
	assert( (tokens = malloc(sizeof(char*)*MAX_TOKENS)) != NULL);
	assert( (pipeTokens = malloc(sizeof(char**)*MAX_TOKENS)) != NULL);

	// allocate space for process PIDs
	assert( (processes = malloc(sizeof(int)*MAX_PROCESSES)) != NULL);
	assert( (commands = malloc(sizeof(char*)*MAX_PROCESSES)) != NULL);

	// open stdin as a file pointer
	assert( (fp = fdopen(STDIN_FILENO, "r")) != NULL);

}

void tokenize (char * string)
{
	// Initialize background process to false
	is_bg = 0;
	// Initalize read from input file to false
	redirect_in = 0;
	// Initalize write to output file to false
	redirect_out = 0;
	// Initalize pipe process to false
	is_piped = 0;
	int token_count = 0;
	int size = MAX_TOKENS;
	char *this_token;

	while ( (this_token = strsep( &string, " \t\v\f\n\r")) != NULL) {

		if (*this_token == '\0'){
			continue;
		}

		////Account for & meta shell character////
		char *background_Token = "&";
		if (strcmp(this_token, background_Token) == 0) {
			is_bg = 1;
			continue;
		}

		// Check if input recieved contains arguments after &
		if (is_bg == 1) {
			printf("Arugnment %s is Ignored Following &\n", this_token);
			continue;
		}
		//////////////////////////////////////////

		// Check if process is reading from input file
		if ((redirect_in == 1) && (inputFile == NULL)) {
			inputFile = this_token;
		}

		// Check if process is writing to output file
		else if ((redirect_out == 1) && (outputFile == NULL)) {
			outputFile = this_token;
		}

		else {
			////Account for Input from File////
			char *filein = "<";
			if (strcmp(this_token, filein) == 0) {
				redirect_in = 1;
				continue;
			}
			//////////////////////////////////

			////Account for Input from File////
			char *fileout = ">";
			if (strcmp(this_token, fileout) == 0) {
				redirect_out = 1;
				continue;
			}
			//////////////////////////////////

			////Account for Piped Process////
			char *pipeToken = "|";
			if (strcmp(this_token, pipeToken) == 0) {

				//Copy contents of tokens into pipeToken array
				char **p = malloc(sizeof(tokens));
				for(int i=0; i < token_count; i++) {
					char *temp = malloc(sizeof(tokens[i]));
					strcpy(temp, tokens[i]);
					p[i] = temp;
				}

				pipeTokens[is_piped] = p;
				//printf("Pipe Token %d: %p\n", is_piped, pipeTokens[is_piped]);

				is_piped++;
				// if there are more tokens than space ,reallocate more space
				if(is_piped >= size){
					size*=2;

					assert ( (pipeTokens = realloc(pipeTokens, sizeof(char**) * size)) != NULL);
				}

				token_count = 0;
				continue;
			}
			//////////////////////////////////

			tokens[token_count] = this_token;

			printf("Token %d: %s\n", token_count, tokens[token_count]);

			token_count++;
			// if there are more tokens than space ,reallocate more space
			if(token_count >= size){
				size*=2;

				assert ( (tokens = realloc(tokens, sizeof(char*) * size)) != NULL);
			}
		}
	}

	//If pipes exist, move everything in tokens to pipeTokens array
	if (is_piped > 0) {

		//Copy contents of tokens into pipeToken array
		char **p = malloc(sizeof(tokens));
		for(int i=0; i < token_count; i++) {
			char *temp = malloc(sizeof(tokens[i]));
			strcpy(temp, tokens[i]);
			p[i] = temp;
		}

		pipeTokens[is_piped] = p;
		//printf("Pipe Token %d: %s\n", is_piped, pipeTokens[is_piped][0]);

		// if there are more tokens than space ,reallocate more space
		if(is_piped >= size){
			size*=2;

			assert ( (pipeTokens = realloc(pipeTokens, sizeof(char**) * size)) != NULL);
		}

		token_count = 0;
	}

	tokens[token_count] = NULL;
	if(is_piped == 0){
		pipeTokens[0] = NULL;
	} else {
		pipeTokens[is_piped+1] = NULL;
	}

}

//Store PID for all running background processes
void store_bg_pid(int pid, char * token)
{
	int size = MAX_PROCESSES;
	char *cmd = malloc(5);
	strcpy(cmd, token);

	//Store current running bg process pid and command
	processes[processes_count] = pid;
	commands[processes_count] = cmd;

	//Incremenet number of background process executed
	processes_count++;

	// if there are more tokens than space ,reallocate more space
	if(processes_count >= size){
		size*=2;

		assert ( (processes = realloc(processes, sizeof(int) * size)) != NULL);
		assert ( (commands = realloc(commands, sizeof(char*) * size)) != NULL);
	}
}

void list_jobs()
{
	printf("List of background processes:\n");
	pid_t pid_i;
	char* cmd_i;

	for (int i = 0; i < processes_count; i++) {
		pid_i = processes[i];
		cmd_i = commands[i];

		if (kill(pid_i, 0) == 0) { //then process is still running
			//status = 0;
			printf("Command %s with PID %d  Status: RUNNING \n", cmd_i, pid_i);
		}
		else if (kill(pid_i,0) == -1) {
			//status = 1;
			printf("Command %s with PID %d Status: FINISHED \n", cmd_i, pid_i);
		}
	}
}

void pipe_handle()
{
	int status;
	pid_t cpid;
	int fd_total = 2*is_piped; 

	//Create file descriptor
	int fds[fd_total];

	for(int i=0; i < is_piped; i++) {
		// Create a pipe
		if(pipe(fds + i*2) < 0) {
			perror ("PIPE CREATION FAILED");
			exit(1);
		}
	}

	// Loop through each process, fork, generate pipe communication, and execute
	for (int j=0; j < (is_piped+1); j++) {
		cpid = fork();

		if(cpid < 0) {
			perror ("FORK FAILED");
			exit(1);
		}
		if (cpid == 0) {
			//Check if processing last fork process
			if(j != (is_piped)) {
				// Make output end of each pipe equal to stdout
				dup2(fds[(2*j)+1], 1);

			}
			//Check if processing first fork process
			if(j != 0) {
				// Make input end of pipe equal to stdin
				dup2(fds[(2*j)-2], 0);
			}

			for(int i=0; i<fd_total; i++){
				close(fds[i]);
			}

			printf("%s\n", pipeTokens[j][0]);

			if(execvp(pipeTokens[j][0],pipeTokens[j]) < 0) {
				perror ("INVALID CMD");
				exit(1);
			}
		}
	}

	////Parent Process////
	//Close parent file descriptors
	for(int i=0; i < fd_total; i++) {
		close (fds[i]);
	}

	if(is_bg == 0){
		for(int i=0; i < is_piped; i++) {
			if(wait(&status) < 0 ){
				perror ("WAITPID FAILED");
				exit(2);
			}
		}
	}
}

void read_command()
{
	// getline will reallocate if input exceeds max length
	assert( getline(&line, &MAX_LINE_LEN, fp) > -1);

	printf("Shell read this line: %s\n", line);

	tokenize(line);
}

int run_command() {

	// Check for any children of background proccess that have finished
	waitpid(-1, NULL, WNOHANG);

	if (tokens[0] == NULL && pipeTokens[0] == NULL) {
		perror("Please Enter a Command");
	}

	// Check if pipe process
	else if (is_piped > 0) {
		pipe_handle();
	}

	else if (strcmp( tokens[0], EXIT_STR ) == 0) {
		return EXIT_CMD;
	}

	// Check if user requested a list of running jobs
	else if (strcmp( tokens[0], "listjobs") == 0 ) {
		list_jobs();
	}

	// Check if user requested to move a process to foreground
	else if (strcmp( tokens[0], "fg") == 0) {
		pid_t w;
		int status;

		int in_proccesses_array = 0;

		if (tokens[1] != NULL) {
			w = atoi(tokens[1]);

			for (int i = 0; i < processes_count; i++) {
				if (processes[i] == w) {
					in_proccesses_array = 1;
				}
			}

			if (in_proccesses_array == 1) {
				printf("PID %d moving to foreground.\n", w);
				waitpid(w, &status, 0);
			}
			else {
				printf("PID %d not a valid background process.\n", w);
			}
		}
	}

	else {
		pid_t cpid; //child pid
		int status; //status of child pid

		cpid = fork();

		if(cpid < 0) {
			perror ("FORK FAILED");
			exit(1);
		}

		//Child Process
		else if(cpid == 0) {

			// Check if command arguments are passed in through input file
			if(redirect_in) {

				int fd = open(inputFile, O_RDONLY);
				if(fd < 0) {
					perror("FAILED TO READ FILE");
				}

				dup2(fd, 0);
				close(fd);
			}

			// Check if command output is writen to file
			if(redirect_out) {

				int fd = open(outputFile, O_CREAT | O_TRUNC | O_WRONLY);
				if(fd < 0) {
					perror("FAILED TO WRITE TO FILE");
				}

				dup2(fd, 1);
				close(fd);
			}

			if(execvp(tokens[0],tokens) < 0) {
				perror ("INVALID CMD");
				exit(1);
			}
			exit(0);
		}

		//Parent Process
		else {
			if(is_bg == 0){
				if(waitpid(cpid, &status, 0) < 0 ){
					perror ("WAITPID FAILED");
					exit(2);
				}
			}
			else {
				store_bg_pid(cpid, tokens[0]);
			}
		}
	}
	return UNKNOWN_CMD;
}

int main()
{
	initialize();

	do {
		printf("sh550> ");
		read_command();

	} while( run_command() != EXIT_CMD );

	return 0;
}
